# Gestos con las manos > 2024-09-11 8:30pm
https://universe.roboflow.com/carritoproject/gestos-con-las-manos

Provided by a Roboflow user
License: CC BY 4.0

